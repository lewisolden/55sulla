import React from 'react';

const Module3 = () => {
  return (
    <div>
      <h1>Module 3: What is a blockchain?</h1>
      <p>Content for Module 3 coming soon...</p>
    </div>
  );
};

export default Module3;
