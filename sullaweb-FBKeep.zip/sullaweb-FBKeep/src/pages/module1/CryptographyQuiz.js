import React, { useState } from 'react';

const CryptographyQuiz = () => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState(null);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [showExplanation, setShowExplanation] = useState(false);

  const updateProgress = (moduleId, sectionId, completed) => {
    console.log(`Progress updated: Module ${moduleId}, Section ${sectionId}, Completed: ${completed}`);
  };

  const quizQuestions = [
    {
      question: "What is the purpose of hash functions in blockchain technology?",
      options: [
        "To encrypt messages between users",
        "To create new cryptocurrencies",
        "To generate fixed-size outputs from any input data",
        "To store private keys"
      ],
      correctAnswer: 2,
      explanation: "Hash functions convert input data of any size into a fixed-size output. In blockchain, they're used to create unique identifiers for blocks and ensure data integrity."
    },
    {
      question: "What is the relationship between public and private keys in cryptocurrency?",
      options: [
        "They are the same key",
        "Private keys can be derived from public keys",
        "Public keys are derived from private keys",
        "They are completely unrelated"
      ],
      correctAnswer: 2,
      explanation: "Public keys are mathematically derived from private keys through cryptographic algorithms, but it's practically impossible to derive the private key from a public key."
    },
    {
      question: "What is the primary purpose of digital signatures in cryptocurrency transactions?",
      options: [
        "To encrypt transaction data",
        "To prove ownership and authorize transactions",
        "To speed up transaction processing",
        "To reduce transaction fees"
      ],
      correctAnswer: 1,
      explanation: "Digital signatures are used to prove ownership of cryptocurrency and authorize transactions by demonstrating possession of the private key associated with the funds."
    },
    {
      question: "What is the key characteristic of a cryptographic hash function?",
      options: [
        "It is easily reversible",
        "It produces random outputs",
        "It produces variable-length outputs",
        "It is deterministic (same input always produces same output)"
      ],
      correctAnswer: 3,
      explanation: "A key characteristic of cryptographic hash functions is that they are deterministic - the same input will always produce the same output hash value."
    },
    {
      question: "What is the significance of 'immutability' in blockchain cryptography?",
      options: [
        "Data can be easily modified",
        "Data cannot be changed once recorded",
        "Data is automatically encrypted",
        "Data is compressed to save space"
      ],
      correctAnswer: 1,
      explanation: "Immutability means that once data is recorded on the blockchain, it cannot be changed or tampered with due to the cryptographic links between blocks and consensus mechanisms."
    }
  ];

  const handleAnswerSelect = (optionIndex) => {
    setSelectedAnswer(optionIndex);
    setShowExplanation(true);
  };

  const moveToNextQuestion = () => {
    const isCorrect = selectedAnswer === quizQuestions[currentQuestion].correctAnswer;
    
    if (isCorrect) {
      setScore(prev => prev + 1);
    }

    if (currentQuestion < quizQuestions.length - 1) {
      setCurrentQuestion(prev => prev + 1);
      setSelectedAnswer(null);
      setShowExplanation(false);
    } else {
      setShowResult(true);
      const passThreshold = quizQuestions.length * 0.6;
      updateProgress(1, 'cryptography-quiz', score >= passThreshold);
    }
  };

  const restartQuiz = () => {
    setCurrentQuestion(0);
    setSelectedAnswer(null);
    setShowResult(false);
    setScore(0);
    setShowExplanation(false);
  };

  if (showResult) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-2xl">
        <div className="bg-white shadow-lg rounded-lg p-8 text-center">
          <h2 className="text-3xl font-bold mb-4 text-blue-800">
            Quiz Completed!
          </h2>
          <p className="text-xl mb-4">
            You scored {score} out of {quizQuestions.length}
          </p>
          {score >= 3 ? (
            <div className="bg-green-100 border-l-4 border-green-500 p-4 mb-4">
              <p className="text-green-700">
                🎉 Congratulations! You've passed the Basic Cryptography quiz!
              </p>
            </div>
          ) : (
            <div className="bg-red-100 border-l-4 border-red-500 p-4 mb-4">
              <p className="text-red-700">
                You didn't pass this time. Review the content and try again.
              </p>
            </div>
          )}
          <button 
            onClick={restartQuiz}
            className="bg-blue-500 text-white px-6 py-2 rounded hover:bg-blue-600"
          >
            Restart Quiz
          </button>
        </div>
      </div>
    );
  }

  const currentQuizQuestion = quizQuestions[currentQuestion];

  return (
    <div className="container mx-auto px-4 py-8 max-w-2xl">
      <div className="bg-white shadow-lg rounded-lg p-8">
        <div className="mb-6">
          <h2 className="text-2xl font-bold text-blue-800 mb-4">
            Basic Cryptography Quiz
            <span className="text-sm ml-4 text-gray-600">
              Question {currentQuestion + 1} of {quizQuestions.length}
            </span>
          </h2>
          
          <div className="bg-blue-50 rounded-lg p-4 mb-6">
            <p className="text-lg text-gray-700">
              {currentQuizQuestion.question}
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            {currentQuizQuestion.options.map((option, index) => (
              <button
                key={index}
                onClick={() => handleAnswerSelect(index)}
                className={`
                  w-full p-4 rounded-lg text-left transition-all duration-300
                  ${selectedAnswer === null 
                    ? 'bg-gray-100 hover:bg-blue-100' 
                    : index === currentQuizQuestion.correctAnswer 
                      ? 'bg-green-200' 
                      : selectedAnswer === index 
                        ? 'bg-red-200' 
                        : 'bg-gray-100'}
                `}
                disabled={selectedAnswer !== null}
              >
                {option}
              </button>
            ))}
          </div>

          {showExplanation && (
            <div className={`
              mt-6 p-4 rounded-lg
              ${selectedAnswer === currentQuizQuestion.correctAnswer 
                ? 'bg-green-100 border-l-4 border-green-500' 
                : 'bg-red-100 border-l-4 border-red-500'}
            `}>
              <h3 className="font-bold mb-2">
                {selectedAnswer === currentQuizQuestion.correctAnswer 
                  ? '✅ Correct!' 
                  : '❌ Incorrect'}
              </h3>
              <p>{currentQuizQuestion.explanation}</p>
            </div>
          )}

          {selectedAnswer !== null && (
            <button
              onClick={moveToNextQuestion}
              className="mt-6 w-full bg-blue-500 text-white py-3 rounded-lg hover:bg-blue-600"
            >
              {currentQuestion < quizQuestions.length - 1 
                ? 'Next Question' 
                : 'Finish Quiz'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default CryptographyQuiz;
