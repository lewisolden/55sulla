import React from 'react';

const Module2 = () => {
  return (
    <div>
      <h1>Module 2: What is a blockchain?</h1>
      <p>Content for Module 2 coming soon...</p>
    </div>
  );
};

export default Module2;
